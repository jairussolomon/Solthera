#!/bin/csh -f

##########################################################
# CREATED    : 06/16/2026 14:24:14 by icd17 (leon)
# INNOVUS  : 21.15-s110_1 (Linux)
##########################################################

# Set testDir to the testcase installation directory \
setenv testDir `which $0 | sed 's/\(.*\)\/\(.*\)/\1/'`
if (! -e $0) setenv testDir /home/icd17/23BVD1040/Solthera/testcase

# Start innovus \
innovus  -64  -overwrite  -files ${testDir}/testcase.tcl

# End csh script \
exit
