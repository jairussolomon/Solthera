global testDir
global dataDir
global libDir
create_library_set -name fast\
   -timing\
    [list ${libDir}/mmmc/fast.lib\
    ${libDir}/lib/typ/MEM1_256X32_slow.lib\
    ${libDir}/lib/typ/MEM2_128X32_slow.lib]
create_library_set -name slow\
   -timing\
    [list ${libDir}/lib/typ/slow.lib\
    ${libDir}/lib/typ/MEM1_256X32_slow.lib\
    ${libDir}/lib/typ/MEM2_128X32_slow.lib]
create_rc_corner -name rc_best\
   -cap_table ${libDir}/mmmc/capTable\
   -preRoute_res 1.34236\
   -postRoute_res 1.34236\
   -preRoute_cap 1.10066\
   -postRoute_cap 0.960235\
   -postRoute_xcap 1.22327\
   -preRoute_clkres 0\
   -preRoute_clkcap 0\
   -postRoute_clkcap {0.969117 0 0}\
   -T 0\
   -qx_tech_file ${libDir}/mmmc/qrcTechFile\
   -qx_conf_file ${libDir}/mmmc/qrc.conf
create_rc_corner -name rc_worst\
   -cap_table ${libDir}/mmmc/capTable\
   -preRoute_res 1.34236\
   -postRoute_res 1.34236\
   -preRoute_cap 1.10066\
   -postRoute_cap 0.960234\
   -postRoute_xcap 1.22327\
   -preRoute_clkres 0\
   -preRoute_clkcap 0\
   -postRoute_clkcap {0.969117 0 0}\
   -T 125\
   -qx_tech_file ${libDir}/mmmc/qrcTechFile\
   -qx_conf_file ${libDir}/mmmc/qrc.conf
create_delay_corner -name slow_max\
   -library_set slow\
   -rc_corner rc_worst
create_delay_corner -name fast_min\
   -library_set fast\
   -rc_corner rc_best
create_constraint_mode -name functional_func_slow_max\
   -sdc_files\
    [list ${dataDir}/leon.enc.dat/mmmc/modes/functional_func_slow_max/functional_func_slow_max.sdc]
create_analysis_view -name func_slow_max -constraint_mode functional_func_slow_max -delay_corner slow_max -latency_file ${dataDir}/leon.enc.dat/mmmc/views/func_slow_max/latency.sdc
create_analysis_view -name func_fast_min -constraint_mode functional_func_slow_max -delay_corner fast_min -latency_file ${dataDir}/leon.enc.dat/mmmc/views/func_fast_min/latency.sdc
set_analysis_view -setup [list func_slow_max] -hold [list func_fast_min]
